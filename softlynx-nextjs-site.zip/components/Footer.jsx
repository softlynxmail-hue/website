export default function Footer(){
  return (
    <footer className="bg-slate-900 text-white p-8 mt-12">
      <div className="max-w-6xl mx-auto text-center">
        <p>© {new Date().getFullYear()} Softlynx Dataworks Pvt Ltd. All rights reserved.</p>
        <p className="text-sm mt-2">Email: info@softlynxdataworks.com</p>
      </div>
    </footer>
  )
}
