import { useState } from 'react'
export default function ChatbotWidget(){
  const [open,setOpen] = useState(false)
  return (
    <div className="fixed bottom-6 right-6">
      {open && (
        <div className="w-80 h-96 bg-white shadow-lg rounded-lg p-3">Bot UI (connect API)</div>
      )}
      <button onClick={()=>setOpen(!open)} className="bg-blue-600 text-white px-4 py-3 rounded-full shadow-lg">Chat</button>
    </div>
  )
}
