export default function About(){
  return (
    <section className="max-w-6xl mx-auto p-8">
      <h2 className="text-3xl font-bold mb-4">About Softlynx Dataworks</h2>
      <p>We are a data-focused technology company providing solutions in Snowflake, AWS, and cloud-native engineering.</p>
    </section>
  )
}
