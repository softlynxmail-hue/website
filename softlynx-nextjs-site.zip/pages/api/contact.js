// Simple email endpoint using nodemailer. Configure SMTP credentials via ENV.
import nodemailer from 'nodemailer'
export default async function handler(req,res){
  if(req.method !== 'POST') return res.status(405).end()
  const { name, email, message } = req.body
  try{
    const transporter = nodemailer.createTransport({
      host: process.env.SMTP_HOST,
      port: Number(process.env.SMTP_PORT || 587),
      auth: { user: process.env.SMTP_USER, pass: process.env.SMTP_PASS },
      secure: (process.env.SMTP_SECURE === 'true')
    })
    await transporter.sendMail({
      from: 'no-reply@softlynxdataworks.com',
      to: process.env.CONTACT_EMAIL || 'info@softlynxdataworks.com',
      subject: `Website contact from ${name}`,
      text: `${message}\n\nReply to: ${email}`
    })
    res.status(200).json({ ok: true })
  }catch(err){
    console.error(err)
    res.status(500).json({ error: 'send_failed' })
  }
}
