import ChatbotWidget from '../components/ChatbotWidget'
export default function Home(){
  return (
    <section className="max-w-6xl mx-auto p-8">
      <div className="grid md:grid-cols-2 gap-8 items-center">
        <div>
          <h1 className="text-4xl font-extrabold mb-4">Data Engineering • Cloud • AI</h1>
          <p className="text-lg">We modernize data platforms with Snowflake, AWS and AI-powered solutions.</p>
        </div>
        <div className="p-6 bg-white rounded-lg shadow">
          <h3 className="font-bold mb-2">Our Capabilities</h3>
          <ul className="list-disc pl-5">
            <li>Snowflake migrations & optimization</li>
            <li>ETL pipelines, S3, Lambda, Snowpipe</li>
            <li>AI automation & ChatGPT integrations</li>
          </ul>
        </div>
      </div>
      <ChatbotWidget />
    </section>
  )
}
