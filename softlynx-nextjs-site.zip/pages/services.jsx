export default function Services(){
  return (
    <section className="max-w-6xl mx-auto p-8">
      <h2 className="text-3xl font-bold mb-4">Services</h2>
      <div className="grid md:grid-cols-3 gap-6">
        <div className="p-6 bg-white rounded-lg shadow">Snowflake Development</div>
        <div className="p-6 bg-white rounded-lg shadow">Cloud Data Engineering</div>
        <div className="p-6 bg-white rounded-lg shadow">AI & Automation</div>
      </div>
    </section>
  )
}
