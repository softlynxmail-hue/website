import '../styles/globals.css'
import Navbar from '../components/Navbar'
import Footer from '../components/Footer'
export default function MyApp({ Component, pageProps }) {
  return (
    <>
      <Navbar />
      <main className="min-h-[70vh]"><Component {...pageProps} /></main>
      <Footer />
    </>
  )
}
