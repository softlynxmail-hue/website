# Softlynx Dataworks - Next.js Starter

## Setup (locally)
1. Save files as per repository structure.
2. Run:

```
npm install
npm run dev
```

3. Open http://localhost:3000

## Environment variables (for contact API)
Create a `.env.local` with:
```
SMTP_HOST=smtp.example.com
SMTP_PORT=587
SMTP_USER=youruser
SMTP_PASS=yourpass
SMTP_SECURE=false
CONTACT_EMAIL=info@softlynxdataworks.com
```

## Deploying to Vercel
1. Push repository to GitHub.
2. Import the repo in Vercel and deploy.
3. Add the domain `softlynxdataworks.com` in Vercel dashboard and follow DNS instructions.

## Google Search Console & Indexing
1. Add property in Search Console (domain property recommended).
2. Verify via DNS TXT record.
3. Submit `https://www.softlynxdataworks.com/sitemap.xml` in Search Console.
